local AddonName = ...
local L = LibStub("AceLocale-3.0"):NewLocale(AddonName, "deDE")
if not L then return end

L.Updated = "Aktualisiert auf v%s"
L.Pulse = "Pulse"
L.Shine = "Shine"