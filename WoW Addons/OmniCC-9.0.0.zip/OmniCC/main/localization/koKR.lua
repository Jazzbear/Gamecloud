local AddonName = ...
local L = LibStub("AceLocale-3.0"):NewLocale(AddonName, "koKR")
if not L then return end

L.Updated = "v%s로 업데이트되었습니다."
L.Pulse = "맥박"
L.Shine = "반짝임"